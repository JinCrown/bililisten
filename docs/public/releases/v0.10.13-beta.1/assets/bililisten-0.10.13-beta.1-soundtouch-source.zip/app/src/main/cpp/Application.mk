APP_ABI := armeabi-v7a arm64-v8a x86 x86_64
APP_PLATFORM := android-26
APP_STL := c++_shared
APP_OPTIM := release
APP_CPPFLAGS := -std=c++17 -fexceptions
APP_SUPPORT_FLEXIBLE_PAGE_SIZES := true
